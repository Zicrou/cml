declare module "amazon-cognito-auth-js/dist/amazon-cognito-auth";
declare module "google-map-react";
