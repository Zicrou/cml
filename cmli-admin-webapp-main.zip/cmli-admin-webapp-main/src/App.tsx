import React from "react";
import Router from "./router";
import "./App.css";

function App() {
  return (
    <>
      <Router />
    </>
  );
}

export default App;
