export const NoPeopleListingState = () => {
  return <p className="no-user-found">No users found ☹️</p>;
};
