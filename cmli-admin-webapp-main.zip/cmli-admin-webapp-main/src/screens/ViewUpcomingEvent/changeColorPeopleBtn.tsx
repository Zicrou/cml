export const changeColorPeopleBtn = () => {
  const x = document.getElementById("peopleBtnId")!;
  x.style.backgroundColor = "#00BFD8";
  const y = document.getElementById("matchesBtnId")!;
  y.style.backgroundColor = "#8EB5B9";
  const z = document.getElementById("chartBtnId")!;
  z.style.backgroundColor = "#8EB5B9";
};
