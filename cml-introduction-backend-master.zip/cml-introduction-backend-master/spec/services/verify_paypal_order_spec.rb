require 'rails_helper'

RSpec.describe VerifyPaypalOrder, type: :model do
  xit { is_expected.to validate_presence_of(:order_id) }
end
