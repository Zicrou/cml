require 'rails_helper'

RSpec.describe VerifyAwsUser, type: :model do
  xit { is_expected.to validate_presence_of(:access_token) }
end
