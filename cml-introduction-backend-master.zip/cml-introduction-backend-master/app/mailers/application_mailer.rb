class ApplicationMailer < ActionMailer::Base
  default from: 'CML Introductions <noreply@centerformuslimlife.com>'
  layout 'mailer'
end
