Time::DATE_FORMATS[:custom_long_ordinal] = '%B %e, %Y %l:%M %P'
